package com.nt.rewardsystem.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nt.rewardsystem.entity.CustomerTransaction;
import com.nt.rewardsystem.entity.RewardPoints;
import com.nt.rewardsystem.exception.CustomerNotFoundException;
import com.nt.rewardsystem.repo.RewardPointsRepository;
import com.nt.rewardsystem.util.RewardPointsCalculator;

@Service
public class RewardService {
	@Autowired
	private  RewardPointsRepository rewardPointsRepository;
	
	private static final Logger logger = LoggerFactory.getLogger(RewardService.class);



    public RewardPoints calculateAndSaveRewards(CustomerTransaction transaction) {
    	logger.info("RewardService : calculateAndSaveRewards start"+transaction);
        int points = RewardPointsCalculator.calculateRewardPoints(transaction.getAmount());
        RewardPoints reward = new RewardPoints();
        reward.setCustomer(transaction.getCustomer());
        reward.setMonth(transaction.getTransactionDate().getMonthValue());
        reward.setYear(transaction.getTransactionDate().getYear());
        reward.setPoints(points);
        logger.info("RewardService : calculateAndSaveRewards end ");
        return rewardPointsRepository.save(reward);
    }

    public List<RewardPoints> getRewardsByCustomerId(Long customerId) {
    	logger.info("RewardService : getRewardsByCustomerId " + customerId);

        // Filter rewards by customer ID
        List<RewardPoints> rewards = rewardPointsRepository.findAll()
                .stream()
                .filter(r -> r.getCustomer().getId().equals(customerId))
                .toList();

        // Throw exception if no rewards are found for the customer
        if (rewards.isEmpty()) {
            throw new CustomerNotFoundException("Customer with ID " + customerId + " not found.");
        }

        return rewards;
    }
    
    public List<RewardPoints> fetchAllRewards() {
    	logger.info("RewardService : fetchAllRewards");
        return rewardPointsRepository.findAll();
    }
    
   
    
}
