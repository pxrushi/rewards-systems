package com.nt.rewardsystem.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.nt.rewardsystem.entity.Customer;
import com.nt.rewardsystem.service.CustomerService;

public class CustomerControllerTest {

    private MockMvc mockMvc;

    @Mock
    private CustomerService customerService;

    @InjectMocks
    private CustomerController customerController;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(customerController).build();
    }

    @Test
    public void testGetAllCustomers() throws Exception {
        // Prepare mock data
        Customer customer1 = new Customer(1L, "raja", "raja@gmail.com");
        Customer customer2 = new Customer(2L, "david", "david.warner@gmail.com");
        List<Customer> customerList = Arrays.asList(customer1, customer2);

        // Mock service method
        when(customerService.getAllCustomers()).thenReturn(customerList);

        // Perform the GET request and verify the result
        mockMvc.perform(get("/api/customers"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].name").value("raja"))
                .andExpect(jsonPath("$[1].name").value("david"));

        verify(customerService, times(1)).getAllCustomers();
    }

    @Test
    public void testGetCustomerById() throws Exception {
        // Prepare mock data
        Customer customer = new Customer(1L, "raja", "raja@gmail.com");

        // Mock service method
        when(customerService.getCustomerById(1L)).thenReturn(customer);

        mockMvc.perform(get("/api/customers/{id}", 1L))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("raja"))
                .andExpect(jsonPath("$.email").value("raja@gmail.com"));

        verify(customerService, times(1)).getCustomerById(1L);
    }

    @Test
    public void testCreateCustomer() throws Exception {
        // Prepare mock data
        Customer customer = new Customer(1L, "raja", "raja@gmail.com");
        Customer savedCustomer = new Customer(1L, "raja", "raja@gmail.com");

        // Mock service method
        when(customerService.saveCustomer(any(Customer.class))).thenReturn(savedCustomer);

        // Perform the POST request and verify the result
        mockMvc.perform(post("/api/customers")
                        .contentType("application/json")
                        .content("{\"name\": \"raja\", \"email\": \"raja@gmail.com\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("raja"))
                .andExpect(jsonPath("$.email").value("raja@gmail.com"));

        verify(customerService, times(1)).saveCustomer(any(Customer.class));
    }
}
